package com.capgemini.exception;

public class AppointementIdNotNullException extends Exception{
	public  AppointementIdNotNullException(String msg)
	{
		super(msg);
	}
}
