package com.capgemini.exception;

public class InvalidAppointementId extends Exception {
	public InvalidAppointementId(String msg)
	{
		super(msg);
	}

}
